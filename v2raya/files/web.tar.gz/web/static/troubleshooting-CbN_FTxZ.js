const o=`<h1 id="故障排除">故障排除</h1>
<p>先看服务日志：Linux 服务单元下是 <code>/var/log/v2raya/v2raya.log</code>，单元自身的输出用 <code>journalctl -u v2raya</code> 查看，其他情况看 <code>--log-file</code> 指定的路径。<strong>日志</strong>页显示同一份内容；<strong>日志等级</strong>设置提高内核的输出详细程度。生成的内核配置是配置目录下的 <code>config.json</code>。</p>
<h2 id="内核启动失败">内核启动失败</h2>
<p><code>CORE_START_FAILED</code> 表示 <code>v2raya_core</code> 无法启动、启动后立即退出，或在 <code>--core-startup-timeout</code> 内没有打开 API 端口，日志里它前面几行说明原因。常见原因：</p>
<ul>
<li><strong>内核版本不匹配</strong>：页面顶部的横幅。<code>v2raya_core</code> 必须与 <code>v2raya</code> 版本相同；放在它位置上的 <code>xray</code> 或 <code>v2ray</code> 不被接受。安装同一版本发布中的 <code>v2raya</code> 与 <code>v2raya_core</code>。</li>
<li><strong><code>illegal domain rule: geosite:...</code></strong>：规则用了 <code>geosite.dat</code> 里没有的类别。可用的名称见分流规则一节。</li>
<li><strong>address already in use</strong>：入站端口被占用。在地址与端口里改端口，或停止占用的程序。53 端口不同：被占用时 DNS 模块跳过那个监听并写入日志，macOS 上由原有解析器继续回答。</li>
<li><strong><code>v2raya_core executable not found</code></strong>：内核不在 <code>v2raya</code> 同目录也不在 <code>PATH</code> 中；用 <code>--v2ray-bin</code> 指定。</li>
</ul>
<h2 id="无法连接">无法连接</h2>
<ul>
<li>仪表板显示分组及成员延迟。节点先按 TCP 探测，TCP 不通时再用 QUIC 报文按 UDP 探测，因此只监听 UDP 的服务器（juicity、tuic、hysteria2）也能测出延迟；<code>TIMEOUT</code> 表示两种探测都没能到达该服务器；换一个节点或检查订阅。</li>
<li>直接测试一个入站：<code>curl -x socks5h://127.0.0.1:20170 https://example.com</code>。入站可用而透明代理不可用时，先查透明代理的配置、DNS 规则和透明代理所走的分组，再怀疑节点。</li>
<li>使用 <code>redirect</code> 或 <code>tproxy</code> 时，Docker 或防火墙可能改写了 iptables 规则；停止再启动内核可重新安装。</li>
<li>Windows 与 macOS 上直接向局域网 DNS 查询的应用会绕过 TUN。</li>
</ul>
<h2 id="规则数据">规则数据</h2>
<p>找到内核后，启动时若缺少 <code>geoip.dat</code> 或 <code>geosite.dat</code>，服务从 GitHub 下载缺少的文件，下载失败则退出。可手动把文件复制到规则数据目录（见参数一节），或安装自带它们的软件包。</p>
<h2 id="升级之后">升级之后</h2>
<p>旧版本的 BoltDB 数据库在首次启动时迁移；旧文件保留为 <code>bolt.db.bak</code>（该名称已存在时为 <code>bolt.db.bak.1</code> 及后续编号），账户需要重新注册。升级前停止服务并复制配置目录，迁移就能从副本重做。</p>
<h2 id="重置密码">重置密码</h2>
<p>停止服务，以服务所用的账户和同样的 <code>--config</code> 与 <code>--lite</code> 参数执行 <code>v2raya --reset-password</code>（Windows 上服务的目录在 <code>%ProgramData%\\SYSTEM</code> 下，不是提权用户的目录），再启动服务并注册。</p>
`;export{o as default};
