const e=`<h1 id="flags-and-environment-variables">Flags and environment variables</h1>
<p>Every flag has an environment variable of the same name: <code>--log-level</code> is <code>V2RAYA_LOG_LEVEL</code>. The Linux service unit sets <code>V2RAYA_LOG_FILE</code> and reads <code>/etc/default/v2raya</code>; the rest keep their defaults. The table below is read from the running service and shows the declared defaults, not the values in effect; an empty default is computed at start.</p>
<h2 id="hooks">Hooks</h2>
<p><code>--transparent-hook</code> names an executable that runs before and after the transparent proxy is set up and torn down, with <code>--transparent-type=&lt;redirect|tproxy|tun|system_proxy&gt;</code>, <code>--stage=&lt;pre-start|post-start|pre-stop|post-stop&gt;</code> and <code>--v2raya-confdir=&lt;directory&gt;</code> as arguments. <code>--core-hook</code> runs before and after the core starts and stops, with <code>--stage</code> and <code>--v2raya-confdir</code>. The route scripts for <code>tun</code> with <strong>Auto Route</strong> off are a separate setting, <strong>Configure Route Script</strong>.</p>
<h2 id="directories">Directories</h2>
<table>
<thead>
<tr>
<th>What</th>
<th>Where</th>
</tr>
</thead>
<tbody><tr>
<td>configuration and <code>v2raya.db</code></td>
<td><code>--config</code>; default <code>/etc/v2raya</code> on Linux and macOS, <code>%ProgramData%\\SYSTEM\\v2rayA</code> for the Windows service, <code>~/.config/v2raya</code> (or <code>%AppData%\\v2rayA</code>) in lite mode</td>
</tr>
<tr>
<td>generated core config</td>
<td><code>config.json</code> in the configuration directory</td>
</tr>
<tr>
<td>rule data (<code>geoip.dat</code>, <code>geosite.dat</code>)</td>
<td><code>--v2ray-assetsdir</code>; otherwise the XDG data directories are searched (<code>/usr/share/v2raya</code>, <code>/usr/local/share/v2raya</code>, <code>~/.local/share/v2raya</code>) and a download lands in the user&#39;s; on Windows the installer&#39;s <code>data</code> directory or the configuration directory</td>
</tr>
<tr>
<td>the core</td>
<td><code>--v2ray-bin</code>; default <code>v2raya_core</code> next to <code>v2raya</code> or in <code>PATH</code></td>
</tr>
<tr>
<td>logs</td>
<td><code>--log-file</code> or <code>V2RAYA_LOG_FILE</code>, else the console; the Linux system unit uses <code>/var/log/v2raya/v2raya.log</code>, the user unit <code>~/.local/state/v2raya/v2raya.log</code>, the Windows installer <code>%TEMP%\\v2raya.log</code></td>
</tr>
</tbody></table>
`;export{e as default};
