const o=`<h1 id="início-rápido">Início rápido</h1>
<p>Esta página no navegador configura o v2rayA e mostra seu estado; o serviço é executado como root (como administrador no Windows; sem privilégios com <code>--lite</code>) e inicia o próprio <code>v2raya_core</code>.</p>
<h2 id="entrar">Entrar</h2>
<p>A primeira conta registrada é a de administrador; não há outra conta. O registro pede um nome de usuário e uma senha de 6 a 32 caracteres e não exige credenciais existentes; por isso, em uma rede compartilhada, restrinja quem pode acessar a porta 2017 antes de se registrar, ou execute o serviço com <code>--address 127.0.0.1:2017</code> para uso apenas local.</p>
<p>Para redefinir uma senha esquecida, use a linha de comando com o serviço parado:</p>
<pre><code class="language-sh">v2raya --reset-password
</code></pre>
<p>Execute o comando com a conta e o diretório <code>--config</code> usados pelo serviço (também com <code>--lite</code> no modo lite); no Windows, o serviço é executado como SYSTEM e seu diretório é diferente do diretório de um usuário com privilégios elevados. Inicie o serviço novamente e registre uma nova conta.</p>
<h2 id="importar-nós">Importar nós</h2>
<p>Na página <strong>Proxies</strong>, <strong>Importar</strong> aceita links de compartilhamento ou uma assinatura: escolha <strong>Link do servidor</strong> para links <code>vmess://</code>, <code>vless://</code>, <code>ss://</code>, <code>trojan://</code>, <code>hysteria2://</code>, <code>tuic://</code>, <code>juicity://</code>, <code>anytls://</code>, <code>wireguard://</code>, <code>socks5://</code>, <code>http://</code> e <code>https://</code>, um por linha, ou uma imagem de código QR; escolha <strong>Endereço da assinatura</strong> para uma assinatura. Links ShadowsocksR são recusados, assim como links Shadowsocks com cifra de fluxo (<code>rc4-md5</code>, <code>aes-*-cfb</code>, <code>chacha20-ietf</code>) ou <code>none</code>: o núcleo aceita apenas as cifras AEAD e os métodos 2022-blake3. <code>allow_insecure</code> em um link é ignorado: o v2rayA nunca pula a verificação do certificado; para um servidor autoassinado, fixe o SHA-256 do certificado no formulário do nó.</p>
<p>As assinaturas têm sua própria página, <strong>Assinaturas</strong> (no celular, a documentação passa para o menu da barra superior para abrir espaço). Elas mantêm seus nós agrupados e podem ser atualizadas manualmente ou por agendamento (<strong>Configurações → Atualizar assinaturas automaticamente</strong>). A configuração de modo ao lado determina se a atualização passa pelo proxy.</p>
<h2 id="grupos">Grupos</h2>
<p>Os nós são usados por meio de grupos de proxy. O grupo <code>proxy</code> sempre existe; outros são criados, configurados e excluídos no botão de grupos da barra superior, o único lugar para isso. Um nó entra em um grupo pelo seu menu, ou selecione vários na página Proxies e escolha o grupo em <strong>Adicionar ao grupo de proxy</strong>. Um grupo com vários membros conectados usa o de menor latência medida (<strong>Automático (menor latência)</strong>); o menu do nó no painel fixa um membro para que o grupo use apenas ele, <strong>Adicionar ou remover nós</strong> altera os membros, e as configurações do grupo definem o endereço e o intervalo de sondagem.</p>
<p>As regras de roteamento usam os nomes dos grupos como saídas: <code>proxy</code> por padrão, e qualquer outro grupo pelo próprio nome assim que tiver um membro conectado.</p>
<h2 id="iniciar-o-núcleo">Iniciar o núcleo</h2>
<p><strong>Iniciar</strong> no painel, ou o botão de estado no topo da página, inicia o <code>v2raya_core</code> com a configuração atual. As alterações na página Configurações entram em vigor com <strong>Salvar e aplicar</strong>: um núcleo em execução é reiniciado com elas, e um núcleo parado as adota na próxima inicialização.</p>
<p>Quando o núcleo está em execução, os aplicativos o acessam pelas entradas locais:</p>
<table>
<thead>
<tr>
<th>Entrada</th>
<th>Endereço</th>
<th>Roteamento</th>
</tr>
</thead>
<tbody><tr>
<td>SOCKS5</td>
<td><code>127.0.0.1:20170</code></td>
<td>tudo pelo <code>proxy</code></td>
</tr>
<tr>
<td>HTTP</td>
<td><code>127.0.0.1:20171</code></td>
<td>tudo pelo <code>proxy</code></td>
</tr>
<tr>
<td>HTTP com regras</td>
<td><code>127.0.0.1:20172</code></td>
<td>a configuração <strong>Modo de divisão de tráfego da porta de regras</strong></td>
</tr>
</tbody></table>
<p>As portas são alteradas em <strong>Configurações → Endereços e portas</strong>; 0 fecha uma entrada. Para atender aos aplicativos sem configurar cada um, ative o proxy transparente.</p>
<h2 id="roteamento">Roteamento</h2>
<p><strong>Configurações → Divisão de tráfego</strong> define como a porta de regras e o proxy transparente dividem o tráfego: usar o proxy para tudo, exceto sites chineses, usar o proxy apenas para a GFWList ou usar suas próprias regras RoutingA. O RoutingA é descrito em sua própria seção.</p>
<h2 id="teclado">Teclado</h2>
<ul>
<li>Página Proxies, visão em lista: <code>Ctrl</code>+<code>A</code> seleciona todos os nós listados e <code>Esc</code> limpa a seleção; <code>/</code> vai para a busca nas páginas Proxies e Registros.</li>
<li>Configurações: <code>Ctrl</code>+<code>S</code> salva. Editor RoutingA: <code>Ctrl</code>+<code>S</code> salva, <code>Tab</code> indenta.</li>
<li>Diálogos com área de texto (importar, assinatura, scripts de rota, listas): <code>Ctrl</code>+<code>Enter</code> envia; <code>Esc</code> fecha qualquer diálogo.</li>
<li>Registros: com foco, <code>Home</code>, <code>End</code>, <code>PgUp</code> e <code>PgDn</code> percorrem o registro.</li>
</ul>
<p>No macOS, <code>Cmd</code> corresponde a <code>Ctrl</code>.</p>
`;export{o as default};
