const e=`<h1 id="transparent-proxy">Transparent proxy</h1>
<p>With the transparent proxy on, traffic reaches the core without any application setting; what is covered depends on the implementation. <strong>Settings → Transparent Proxy/System Proxy</strong> turns it on and picks the splitting policy; the setting below it picks the implementation.</p>
<h2 id="policies">Policies</h2>
<table>
<thead>
<tr>
<th>Policy</th>
<th>Traffic through the proxy</th>
</tr>
</thead>
<tbody><tr>
<td>Do not split</td>
<td>everything</td>
</tr>
<tr>
<td>Proxy except CN sites</td>
<td>everything except Chinese domains and addresses (<code>geosite:cn</code>, <code>geoip:cn</code>) and private addresses; sites outside China, Google and Hong Kong and Macao addresses are proxied even when a Chinese rule would match</td>
</tr>
<tr>
<td>Proxy only GFWList</td>
<td>the domains on the GFWList (<code>gfw</code> and <code>greatfire</code> from Loyalsoldier&#39;s file) and Telegram&#39;s address ranges; run <strong>Update GFWList</strong> first, the mode is refused without the file</td>
</tr>
<tr>
<td>Same as the rule port</td>
<td>the rule port&#39;s mode, including RoutingA</td>
</tr>
</tbody></table>
<h2 id="implementations">Implementations</h2>
<table>
<thead>
<tr>
<th>Implementation</th>
<th>Platforms</th>
<th>Notes</th>
</tr>
</thead>
<tbody><tr>
<td><code>redirect</code></td>
<td>Linux</td>
<td>iptables/nftables <code>REDIRECT</code>; TCP only, plus DNS on port 53 redirected to the core&#39;s DNS module (port 52353) in the <em>service and interception</em> mode</td>
</tr>
<tr>
<td><code>tproxy</code></td>
<td>Linux</td>
<td>iptables/nftables <code>TPROXY</code>; TCP and UDP</td>
</tr>
<tr>
<td><code>tun</code></td>
<td>Linux, Windows, macOS</td>
<td>the core opens a TUN device; TCP and UDP; excludes v2rayA and the core by itself</td>
</tr>
<tr>
<td>System proxy</td>
<td>Windows; Linux and macOS when not running as root (<code>--lite</code>)</td>
<td>sets the desktop&#39;s proxy settings (GNOME and KDE on Linux); only applications that honour them are covered</td>
</tr>
</tbody></table>
<p><code>redirect</code> and <code>tproxy</code> need root and <code>iptables</code> or <code>nftables</code>; <code>tun</code> needs <code>/dev/net/tun</code> and <code>ip</code> on Linux and administrator rights on Windows and macOS.</p>
<p><strong>Excluded Interface Prefixes</strong> keeps traffic arriving on the named interfaces (Docker bridges, VPN tunnels; <code>docker*</code>, <code>veth*</code>, <code>wg*</code>, <code>ppp*</code> by default) out of <code>redirect</code> and <code>tproxy</code>; their DNS is still intercepted in the <em>service and interception</em> mode.</p>
<p><code>--redirect-respect-bound-device</code> (Linux) lets TCP sockets bound to a device with <code>SO_BINDTODEVICE</code> bypass <code>redirect</code>: NetworkManager&#39;s connectivity checks are such sockets, and a redirected check reports a limited connection and keeps applications offline. Off by default. When it is on, the service marks those sockets with <code>0x80</code> through cgroup BPF; that needs kernel 5.14 or later and cgroup v2, and <code>redirect</code> fails to start when they are missing.</p>
<h2 id="tun">TUN</h2>
<p>The core creates the TUN device and assigns its address. With <strong>Auto Route</strong> on, v2rayA installs the routes and, in the <em>service and interception</em> mode, points the system resolver at the core; with it off, the setup and teardown scripts under <strong>Configure Route Script</strong> do.</p>
<p>What never enters the TUN: the core&#39;s own connections, the <code>direct</code> outbound and the DNS module&#39;s upstream queries (by socket mark on Linux, by binding to the physical interface on Windows and macOS). v2rayA and the core are always excluded; <strong>TUN Excluded Processes</strong> excludes more by executable name, one per line, for connections whose owning process can be identified; in the <em>service and interception</em> mode their DNS still goes to the core&#39;s DNS module. Routes more specific than the default (connected networks, static routes) bypass the TUN as well.</p>
<p>In the <em>service and interception</em> mode, plain DNS on port 53 that reaches the TUN is answered by the core&#39;s DNS module according to the DNS rules; encrypted DNS is not intercepted. On Windows the system resolver is pointed at the TUN gateway, on macOS at the core&#39;s listener on <code>127.0.0.1</code>, which needs port 53 free.</p>
<p>In the other two modes the TUN builds no such relay and neither platform&#39;s system resolver is changed; a query that still arrives is routed directly out of the device. With <strong>Auto Route</strong> off and the route script in charge, the same holds: v2rayA installs no resolver setting, so the script owns DNS as well.</p>
<p>Known limitation: on Windows and macOS an application that queries a LAN resolver directly still bypasses the TUN.</p>
<h2 id="dns">DNS</h2>
<p><strong>Settings → DNS Settings</strong> holds the mode and the rules the core&#39;s DNS module follows.</p>
<table>
<thead>
<tr>
<th>Mode</th>
<th>DNS module</th>
<th>System queries</th>
</tr>
</thead>
<tbody><tr>
<td>Off</td>
<td>not running</td>
<td>untouched</td>
</tr>
<tr>
<td>Service only</td>
<td>running</td>
<td>untouched: the resolvers, the firewall DNS rules and the TUN relay are left alone</td>
</tr>
<tr>
<td>Service and interception</td>
<td>running</td>
<td>redirected to it: the resolver is repointed and port 53 is diverted</td>
</tr>
</tbody></table>
<p>The mode decides two separate things — whether the module runs, and whether the system&#39;s queries are sent to it — which the <em>service only</em> mode answers differently. <code>Off</code> and <em>service only</em> both let plain TCP/UDP 53 pass through <code>redirect</code>, <code>tproxy</code> and the system proxy, and send it straight out of <code>tun</code>; there is no need to leave interception for encrypted DNS, which is never sent to the module. Choose <em>service only</em> when another program already points DNS at v2rayA, and <code>Off</code> when nothing should answer DNS for you at all.</p>
<p>The rules say which upstream answers which domains, and whether the query goes out directly. The defaults send private names to <code>127.0.0.1:53</code> (<code>localhost</code>, which needs a resolver listening there), <code>geosite:cn</code> to <code>223.5.5.5</code> directly, and everything else to <code>1.0.0.1</code> through the proxy. An outbound of <code>direct</code> queries directly; any other value sends the query through the local SOCKS inbound, so it is routed like SOCKS traffic. The rule with an empty domain list answers every domain no other rule names. An upstream is an address (<code>8.8.8.8</code>, <code>dns.google</code>), <code>tcp://host</code>, <code>tls://host</code> for DNS over TLS or <code>https://host/dns-query</code> for DNS over HTTPS; DNS over QUIC is not supported and is refused on save.</p>
<p><code>Off</code> hides the rules and keeps them: nothing would read them, and dropping them would make switching the mode back on a different configuration.</p>
<p>Saving writes the rules and the mode as two requests, and the dialog reports which of them the service accepted. A refusal after the rules were stored is named as such, so the retry sends only what is still missing.</p>
<h2 id="sharing-with-the-lan">Sharing with the LAN</h2>
<p><strong>Port Sharing</strong> makes the SOCKS, HTTP and custom inbounds listen on all interfaces instead of <code>127.0.0.1</code>, so other devices can use this machine as their proxy; the API port stays on loopback. To route their traffic through the transparent proxy as well, use <code>redirect</code>, <code>tproxy</code> or <code>tun</code>, turn on <strong>IP Forward</strong>, keep the interface they arrive on out of the excluded prefixes, and point their default gateway at this machine; the system proxy modes cannot do this.</p>
`;export{e as default};
