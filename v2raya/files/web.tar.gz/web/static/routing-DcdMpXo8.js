const e=`<h1 id="regras-de-roteamento">Regras de roteamento</h1>
<p>RoutingA é a linguagem de regras do v2rayA. <strong>Configurações → RoutingA</strong> abre o editor; as regras se aplicam à porta de regras (<code>20172</code>) quando seu modo é RoutingA e ao proxy transparente quando sua política é <em>Igual ao da porta de regras</em>. Uma entrada personalizada vinculada ao RoutingA tem seu próprio texto de regras, veja abaixo.</p>
<h2 id="sintaxe">Sintaxe</h2>
<p>Uma regra por linha: condições, unidas por <code>&amp;&amp;</code>, seguidas de <code>-&gt;</code> e uma saída. As regras são avaliadas de cima para baixo e a primeira correspondência prevalece; <code>default:</code> indica a saída para tudo que não corresponder a nenhuma regra. Uma linha que começa com <code>#</code> é um comentário. O v2rayA coloca algumas regras próprias antes das demais: os endereços dos servidores proxy e o serviço de notificações push da Apple usam conexão direta, e uma condição <code>inboundTag(...)</code> substitui o escopo de entradas habitual da regra.</p>
<pre><code>default: proxy
domain(geosite:category-ads-all) -&gt; block
domain(geosite:cn) -&gt; direct
ip(geoip:private, geoip:cn) -&gt; direct
</code></pre>
<table>
<thead>
<tr>
<th>Condição</th>
<th>Corresponde a</th>
</tr>
</thead>
<tbody><tr>
<td><code>domain(...)</code></td>
<td><code>domain:</code> o domínio e seus subdomínios, <code>full:</code> correspondência exata, <code>regexp:</code>, <code>geosite:&lt;category&gt;</code>, <code>ext:&quot;file.dat:tag&quot;</code>; um valor sem prefixo, como <code>example.com</code>, corresponde a qualquer domínio que contenha esse texto</td>
</tr>
<tr>
<td><code>ip(...)</code></td>
<td>um endereço, um CIDR (coloque IPv6 entre aspas: <code>ip(&quot;2001:db8::/32&quot;)</code>), <code>geoip:&lt;code&gt;</code>, <code>ext:&quot;file.dat:tag&quot;</code></td>
</tr>
<tr>
<td><code>port(...)</code></td>
<td>portas e intervalos de destino, <code>port(80, 443, 1000-2000)</code></td>
</tr>
<tr>
<td><code>sourcePort(...)</code></td>
<td>portas de origem</td>
</tr>
<tr>
<td><code>network(...)</code></td>
<td><code>tcp</code>, <code>udp</code></td>
</tr>
<tr>
<td><code>protocol(...)</code></td>
<td>protocolo identificado pela inspeção: <code>http</code>, <code>tls</code>, <code>quic</code>, <code>bittorrent</code> (exige <strong>Inspeção de tráfego</strong> ativada)</td>
</tr>
<tr>
<td><code>source(...)</code></td>
<td>endereços e CIDRs de origem</td>
</tr>
<tr>
<td><code>inboundTag(...)</code></td>
<td>a entrada pela qual a conexão chegou</td>
</tr>
</tbody></table>
<h2 id="saídas">Saídas</h2>
<p><code>proxy</code>, <code>direct</code> e <code>block</code> são integradas. Qualquer outro grupo de proxy é uma saída com seu próprio nome assim que tem um membro conectado; caso contrário, as regras não podem ser aplicadas. Um servidor SOCKS ou HTTP externo ao v2rayA é declarado uma vez e usado como um grupo (um arquivo <code>ext:</code> fica no diretório de dados de regras):</p>
<pre><code>outbound: office = socks(address: 192.168.1.10, port: 1080)
outbound: gateway = http(address: 10.0.0.1, port: 8080, user: &#39;name&#39;, pass: &#39;secret&#39;)
domain(domain: corp.example) -&gt; office
</code></pre>
<h2 id="categorias">Categorias</h2>
<p>As categorias <code>geosite:</code> vêm do <a href="https://github.com/v2fly/domain-list-community">domain-list-community</a> do v2fly, e os códigos <code>geoip:</code>, do <a href="https://github.com/v2fly/geoip">v2fly/geoip</a>; o v2rayA baixa os arquivos que faltam na primeira inicialização, mas um pacote pode fornecer sua própria compilação. Usados com frequência: <code>geosite:cn</code>, <code>geosite:geolocation-!cn</code>, <code>geosite:private</code>, <code>geosite:category-ads-all</code>, <code>geosite:greatfire</code>, <code>geosite:netflix</code>, <code>geosite:youtube</code>, <code>geosite:telegram</code>, <code>geosite:openai</code>; <code>geoip:cn</code>, <code>geoip:private</code> e os códigos de países. Um atributo restringe uma categoria: <code>geosite:apple@cn</code>, <code>geosite:category-games@cn</code>.</p>
<p>Nomes que existem apenas nas compilações de Loyalsoldier (<code>gfw</code>, <code>apple-cn</code>, <code>google-cn</code>, <code>geoip:telegram</code>) não estão nesses arquivos; o núcleo os recusa com <code>illegal domain rule</code> ou <code>illegal ip rule</code>. <strong>Atualizar GFWList</strong> baixa essa compilação (de <code>v2rayA/dist-v2ray-rules-dat</code>) como <code>LoyalsoldierSite.dat</code>, e as regras podem então usá-la como <code>domain(ext:&quot;LoyalsoldierSite.dat:gfw&quot;)</code>.</p>
<h2 id="o-editor">O editor</h2>
<p>O modo de lista edita cada regra com um formulário; o modo de texto mostra números de linha, realce de sintaxe e uma verificação por linha. A referência ao lado do editor insere exemplos na posição do cursor, e sua seção <strong>Modelos</strong> contém conjuntos completos de regras para as políticas comuns: insira um antes de suas próprias regras ou substitua todo o conjunto de regras por ele. As regras são importadas e exportadas como um arquivo de texto.</p>
<p>O modelo para a Rússia encaminha <code>geosite:category-ru</code> diretamente, exceto pelos domínios de exceção listados antes dessa regra; todo o restante usa o proxy. Ele é uma cópia incorporada do <a href="https://github.com/wywywywycloud/routinga-russia">routinga-russia</a>, não uma lista atualizada automaticamente, e requer um <code>geosite.dat</code> com <code>category-ru</code>.</p>
<p>Os endereços IP russos (<code>geoip:ru</code>) e os nomes e endereços IP privados (<code>geosite:private</code>, <code>geoip:private</code>) também usam conexão direta; as exceções de proxy têm prioridade.</p>
<p>Salvar recarrega um núcleo em execução com as novas regras; quando o núcleo as rejeita, o v2rayA restaura as regras anteriores e mostra o erro do núcleo, que indica o texto problemático. Um núcleo parado adota as regras na próxima inicialização.</p>
<h2 id="entradas-personalizadas">Entradas personalizadas</h2>
<p>Uma entrada personalizada vinculada ao RoutingA tem seu próprio texto de regras, que se aplica apenas a essa entrada. Ela aceita regras, não definições: linhas <code>default:</code> e <code>outbound:</code> são ignoradas, e o tráfego que não corresponde a nenhuma regra vai para o grupo escolhido no formulário. Termine o texto com uma regra que abranja tudo, como <code>network(tcp, udp) -&gt; direct</code>, para definir por conta própria o roteamento de todo o restante.</p>
`;export{e as default};
