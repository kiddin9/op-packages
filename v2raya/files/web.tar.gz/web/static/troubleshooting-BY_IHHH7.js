const e=`<h1 id="troubleshooting">Troubleshooting</h1>
<p>The service log is the first place to look: <code>/var/log/v2raya/v2raya.log</code> under the Linux service unit, <code>journalctl -u v2raya</code> for what the unit itself prints, the path given by <code>--log-file</code> otherwise. The <strong>Logs</strong> page shows the same stream; the <strong>Log Level</strong> setting raises the core&#39;s verbosity. The generated core configuration is <code>config.json</code> in the configuration directory.</p>
<h2 id="the-core-does-not-start">The core does not start</h2>
<p><code>CORE_START_FAILED</code> means <code>v2raya_core</code> could not be launched, exited right after starting, or did not open its API port within <code>--core-startup-timeout</code>; the lines before it in the log say why. Usual reasons:</p>
<ul>
<li><strong>Core version mismatch</strong> — the banner at the top of the page. <code>v2raya_core</code> must be the same version as <code>v2raya</code>; an <code>xray</code> or <code>v2ray</code> binary in its place is not accepted. Install both from the same release.</li>
<li><strong><code>illegal domain rule: geosite:...</code></strong> — a rule names a category that is not in <code>geosite.dat</code>. See the routing section for which names exist.</li>
<li><strong>address already in use</strong> — an inbound port is taken. Change it under Address and Ports or stop the other program. Port 53 is different: when it is busy the DNS module skips its listener there and says so in the log, and on macOS the existing resolver keeps answering.</li>
<li><strong><code>v2raya_core executable not found</code></strong> — the core is not next to <code>v2raya</code> or in <code>PATH</code>; pass <code>--v2ray-bin</code>.</li>
</ul>
<h2 id="nothing-connects">Nothing connects</h2>
<ul>
<li>The dashboard shows the group and its members&#39; latency. Nodes are probed over TCP, and over UDP with a QUIC packet when TCP fails, so servers that listen on UDP only (juicity, tuic, hysteria2) are measured too; <code>TIMEOUT</code> means neither probe reached the server from this machine. Try another node or check the subscription.</li>
<li>Test one inbound directly: <code>curl -x socks5h://127.0.0.1:20170 https://example.com</code>. If that works and the transparent proxy does not, look at the transparent proxy setup, the DNS rules and the group the transparent proxy routes to before blaming the node.</li>
<li>With <code>redirect</code> or <code>tproxy</code>, Docker or a firewall may have replaced the iptables rules; stop and start the core to reinstall them.</li>
<li>On Windows and macOS, an application that asks a LAN resolver directly for DNS bypasses the TUN.</li>
</ul>
<h2 id="rule-data">Rule data</h2>
<p>Once the core is found, a start without <code>geoip.dat</code> or <code>geosite.dat</code> downloads the missing file from GitHub and exits when the download fails. Copy the files into the rule-data directory by hand (see the parameters section), or install a package that ships them.</p>
<h2 id="after-an-upgrade">After an upgrade</h2>
<p>A BoltDB database from an older release is migrated on the first start; the old file stays as <code>bolt.db.bak</code> (<code>bolt.db.bak.1</code> and up when that name is taken), and the accounts have to be registered again. Stop the service and copy the configuration directory before upgrading, then the migration can be repeated from that copy.</p>
<h2 id="reset-the-password">Reset the password</h2>
<p>Stop the service, run <code>v2raya --reset-password</code> as the account the service uses with the same <code>--config</code> and <code>--lite</code> flags (on Windows the service&#39;s directory is under <code>%ProgramData%\\SYSTEM</code>, not the elevated user&#39;s), start it again and register.</p>
`;export{e as default};
