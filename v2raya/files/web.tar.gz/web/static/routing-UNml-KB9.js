const e=`<h1 id="分流规则">分流规则</h1>
<p>RoutingA 是 v2rayA 的规则语言。<strong>设置 → RoutingA</strong> 打开编辑器；规则作用于模式为 RoutingA 的规则端口（<code>20172</code>）和策略为“与规则端口相同”的透明代理。绑定到 RoutingA 的自定义入站有自己的规则文本，见下文。</p>
<h2 id="语法">语法</h2>
<p>每行一条规则：若干条件以 <code>&amp;&amp;</code> 连接，再接 <code>-&gt;</code> 和出口。规则自上而下匹配，首条匹配的规则生效；<code>default:</code> 指定未匹配流量的出口。以 <code>#</code> 开头的行是注释。v2rayA 会在前面加几条自己的规则：代理服务器的地址与 Apple 推送服务直连；带 <code>inboundTag(...)</code> 条件的规则不再限于原来的入站范围。</p>
<pre><code>default: proxy
domain(geosite:category-ads-all) -&gt; block
domain(geosite:cn) -&gt; direct
ip(geoip:private, geoip:cn) -&gt; direct
</code></pre>
<table>
<thead>
<tr>
<th>条件</th>
<th>匹配对象</th>
</tr>
</thead>
<tbody><tr>
<td><code>domain(...)</code></td>
<td><code>domain:</code> 域名及其子域名，<code>full:</code> 完全匹配，<code>regexp:</code>，<code>geosite:&lt;类别&gt;</code>，<code>ext:&quot;文件.dat:标签&quot;</code>；不带前缀的 <code>example.com</code> 按子串匹配</td>
</tr>
<tr>
<td><code>ip(...)</code></td>
<td>地址、CIDR（IPv6 要加引号：<code>ip(&quot;2001:db8::/32&quot;)</code>）、<code>geoip:&lt;代码&gt;</code>、<code>ext:&quot;文件.dat:标签&quot;</code></td>
</tr>
<tr>
<td><code>port(...)</code></td>
<td>目标端口与范围，如 <code>port(80, 443, 1000-2000)</code></td>
</tr>
<tr>
<td><code>sourcePort(...)</code></td>
<td>源端口</td>
</tr>
<tr>
<td><code>network(...)</code></td>
<td><code>tcp</code>、<code>udp</code></td>
</tr>
<tr>
<td><code>protocol(...)</code></td>
<td>探测到的协议：<code>http</code>、<code>tls</code>、<code>quic</code>、<code>bittorrent</code>（需要开启<strong>嗅探</strong>）</td>
</tr>
<tr>
<td><code>source(...)</code></td>
<td>源地址与 CIDR</td>
</tr>
<tr>
<td><code>inboundTag(...)</code></td>
<td>连接进入的入站</td>
</tr>
</tbody></table>
<h2 id="出口">出口</h2>
<p><code>proxy</code>、<code>direct</code>、<code>block</code> 内置。其他代理分组在有已连接成员后即可按名称作为出口，否则规则无法应用。v2rayA 之外的 SOCKS 或 HTTP 服务器声明一次后像分组一样使用（<code>ext:</code> 的文件放在规则数据目录）：</p>
<pre><code>outbound: office = socks(address: 192.168.1.10, port: 1080)
outbound: gateway = http(address: 10.0.0.1, port: 8080, user: &#39;name&#39;, pass: &#39;secret&#39;)
domain(domain: corp.example) -&gt; office
</code></pre>
<h2 id="类别">类别</h2>
<p><code>geosite:</code> 类别来自 v2fly 的 <a href="https://github.com/v2fly/domain-list-community">domain-list-community</a>，<code>geoip:</code> 代码来自 <a href="https://github.com/v2fly/geoip">v2fly/geoip</a>；v2rayA 首次启动时下载缺少的文件，软件包也可能自带它们的构建。常用的有 <code>geosite:cn</code>、<code>geosite:geolocation-!cn</code>、<code>geosite:private</code>、<code>geosite:category-ads-all</code>、<code>geosite:greatfire</code>、<code>geosite:netflix</code>、<code>geosite:youtube</code>、<code>geosite:telegram</code>、<code>geosite:openai</code>；<code>geoip:cn</code>、<code>geoip:private</code> 与各国家代码。属性可缩小类别范围：<code>geosite:apple@cn</code>、<code>geosite:category-games@cn</code>。</p>
<p>只存在于 Loyalsoldier 构建中的名称（<code>gfw</code>、<code>apple-cn</code>、<code>google-cn</code>、<code>geoip:telegram</code>）不在这两个文件里，内核会以 <code>illegal domain rule</code> 或 <code>illegal ip rule</code> 拒绝。<strong>更新 GFWList</strong> 会把该构建（来自 <code>v2rayA/dist-v2ray-rules-dat</code>）下载为 <code>LoyalsoldierSite.dat</code>，之后规则可以写成 <code>domain(ext:&quot;LoyalsoldierSite.dat:gfw&quot;)</code>。</p>
<h2 id="编辑器">编辑器</h2>
<p>列表模式用表单编辑每条规则；文本模式提供行号、着色和逐行检查。编辑器旁的语法参考可把示例插入到光标处，其中<strong>模板</strong>一节是常见策略的完整规则集：插入到自己的规则之前，或者用它替换整个规则集。规则可导入导出为文本文件。</p>
<p>俄罗斯模板让 <code>geosite:category-ru</code> 直连，但排在它前面的例外域名走代理；其余流量也走代理。此模板是 <a href="https://github.com/wywywywycloud/routinga-russia">routinga-russia</a> 的内置快照，不会自动更新，并且需要包含 <code>category-ru</code> 的 <code>geosite.dat</code>。</p>
<p>俄罗斯 IP 地址（<code>geoip:ru</code>）以及局域网域名和 IP 地址（<code>geosite:private</code>、<code>geoip:private</code>）也直连；代理例外规则优先。</p>
<p>保存后运行中的内核以新规则重新加载；内核拒绝规则时 v2rayA 恢复原规则并显示内核的错误，错误信息指出出错的内容。已停止的内核在下次启动时读取新规则。</p>
<h2 id="自定义入站">自定义入站</h2>
<p>绑定到 RoutingA 的自定义入站有自己的规则文本，只作用于该入站。它只接受规则，不接受定义：<code>default:</code> 与 <code>outbound:</code> 行被忽略，未命中任何规则的流量走表单里选择的分组。要自己决定其余流量的去向，在末尾加一条兜底规则，如 <code>network(tcp, udp) -&gt; direct</code>。</p>
`;export{e as default};
