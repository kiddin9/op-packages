const o=`<h1 id="快速开始">快速开始</h1>
<p>浏览器里的这个页面用来配置 v2rayA 和查看状态；服务以 root 运行（Windows 上为管理员，<code>--lite</code> 则无需特权）并自行启动 <code>v2raya_core</code>。</p>
<h2 id="登录">登录</h2>
<p>第一个注册的账户就是管理员，没有其他账户。注册时设置用户名和 6 到 32 个字符的密码，不需要已有凭据，因此在共享网络中先限制谁能访问 2017 端口再注册，或者只在本机使用时以 <code>--address 127.0.0.1:2017</code> 启动服务。</p>
<p>忘记密码时停止服务，在命令行重置：</p>
<pre><code class="language-sh">v2raya --reset-password
</code></pre>
<p>以服务所用的账户执行，并带上服务所用的 <code>--config</code> 目录（lite 模式再加 <code>--lite</code>）；Windows 上服务以 SYSTEM 运行，它的目录与提权用户的不同。然后重新启动服务并注册新账户。</p>
<h2 id="导入节点">导入节点</h2>
<p>在<strong>代理</strong>页点<strong>导入</strong>，先选类型：<strong>节点链接</strong>用于 <code>vmess://</code>、<code>vless://</code>、<code>ss://</code>、<code>trojan://</code>、<code>hysteria2://</code>、<code>tuic://</code>、<code>juicity://</code>、<code>anytls://</code>、<code>wireguard://</code>、<code>socks5://</code>、<code>http://</code>、<code>https://</code> 链接（每行一条）或二维码图片，<strong>订阅地址</strong>用于订阅。ShadowsocksR 链接会被拒绝；使用流式加密（<code>rc4-md5</code>、<code>aes-*-cfb</code>、<code>chacha20-ietf</code>）或 <code>none</code> 的 Shadowsocks 链接同样被拒绝，内核只接受 AEAD 加密与 2022-blake3 系列。链接里的 <code>allow_insecure</code> 会被忽略：v2rayA 不跳过证书校验，自签名服务器请在节点表单里填入证书的 SHA-256 指纹。</p>
<p>订阅有自己的页面<strong>订阅</strong>（手机上文档入口移到顶栏菜单，给它腾出位置）。订阅的节点归在一起，可手动更新，也可按计划更新（<strong>设置 → 自动更新订阅</strong>）。旁边的模式选项决定更新是否经过代理。</p>
<h2 id="分组">分组</h2>
<p>节点通过代理分组使用。分组 <code>proxy</code> 始终存在，其他分组在顶栏的分组按钮里创建、设置和删除，那里是分组功能的唯一入口。从节点菜单把节点加入分组，或在代理页多选后在<strong>添加到代理组</strong>里选分组。组内有多个已连接成员时使用实测延迟最低的成员（<strong>自动（延迟最低）</strong>）；在仪表板的节点菜单里可指定一个成员，此后该组只经它出站；<strong>增删节点</strong>修改成员，分组设置里设定探测地址与间隔。</p>
<p>分流规则以分组名作为出口：默认是 <code>proxy</code>，其他分组在有已连接成员后按名称使用。</p>
<h2 id="启动内核">启动内核</h2>
<p>仪表板的<strong>启动</strong>或页面顶部的状态按钮以当前配置启动 <code>v2raya_core</code>。设置页的修改在<strong>保存并应用</strong>后生效：内核运行中会带着新配置重启，已停止的内核在下次启动时读取。</p>
<p>内核运行后，应用通过本机入站使用它：</p>
<table>
<thead>
<tr>
<th>入站</th>
<th>地址</th>
<th>分流</th>
</tr>
</thead>
<tbody><tr>
<td>SOCKS5</td>
<td><code>127.0.0.1:20170</code></td>
<td>全部走 <code>proxy</code></td>
</tr>
<tr>
<td>HTTP</td>
<td><code>127.0.0.1:20171</code></td>
<td>全部走 <code>proxy</code></td>
</tr>
<tr>
<td>带规则的 HTTP</td>
<td><code>127.0.0.1:20172</code></td>
<td><strong>规则端口的分流模式</strong>设置</td>
</tr>
</tbody></table>
<p>端口在<strong>设置 → 地址与端口</strong>修改，0 表示关闭该入站。要覆盖应用而不逐个配置，请开启透明代理。</p>
<h2 id="分流">分流</h2>
<p><strong>设置 → 流量分流</strong>决定规则端口和透明代理如何分流：国内站点直连其余走代理、只代理 GFWList，或者自己写的 RoutingA 规则。RoutingA 见单独一节。</p>
<h2 id="快捷键">快捷键</h2>
<ul>
<li>代理页列表视图：<code>Ctrl</code>+<code>A</code> 选中列出的全部节点，<code>Esc</code> 取消选择；代理页与日志页 <code>/</code> 跳到搜索框。</li>
<li>设置页：<code>Ctrl</code>+<code>S</code> 保存。RoutingA 编辑器：<code>Ctrl</code>+<code>S</code> 保存，<code>Tab</code> 缩进。</li>
<li>带多行文本框的对话框（导入、订阅、路由脚本、各类列表）：<code>Ctrl</code>+<code>Enter</code> 提交；<code>Esc</code> 关闭任何对话框。</li>
<li>日志页获得焦点后 <code>Home</code>、<code>End</code>、<code>PgUp</code>、<code>PgDn</code> 翻动日志。</li>
</ul>
<p>macOS 上 <code>Cmd</code> 对应 <code>Ctrl</code>。</p>
`;export{o as default};
