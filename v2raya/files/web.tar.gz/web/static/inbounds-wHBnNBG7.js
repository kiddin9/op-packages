const a=`<h1 id="entradas-e-compartilhamento">Entradas e compartilhamento</h1>
<p>Uma entrada é uma porta na qual o núcleo aceita conexões de aplicativos ou de outros dispositivos.</p>
<h2 id="entradas-integradas">Entradas integradas</h2>
<p><strong>Configurações → Endereços e portas</strong> define essas entradas; 0 fecha uma entrada de proxy e permite que a porta da API seja escolhida aleatoriamente.</p>
<table>
<thead>
<tr>
<th>Entrada</th>
<th>Padrão</th>
<th>Roteamento</th>
</tr>
</thead>
<tbody><tr>
<td>SOCKS5</td>
<td><code>20170</code></td>
<td>tudo pelo <code>proxy</code></td>
</tr>
<tr>
<td>HTTP</td>
<td><code>20171</code></td>
<td>tudo pelo <code>proxy</code></td>
</tr>
<tr>
<td>SOCKS5 com regras</td>
<td>desativada</td>
<td>o modo da porta de regras</td>
</tr>
<tr>
<td>HTTP com regras</td>
<td><code>20172</code></td>
<td>o modo da porta de regras</td>
</tr>
<tr>
<td>VMess com regras</td>
<td>desativada</td>
<td>uma entrada VMess para outros dispositivos; a página mostra seu link de compartilhamento</td>
</tr>
<tr>
<td>API</td>
<td>aleatória</td>
<td>a API do próprio núcleo, usada pelo v2rayA para estatísticas e para o balanceamento</td>
</tr>
</tbody></table>
<p>As entradas de proxy escutam em <code>127.0.0.1</code>. <strong>Compartilhamento de portas</strong> (Configurações → Proxy) faz com que escutem em todas as interfaces para que celulares e outras máquinas da rede local possam usá-las; a porta da API permanece no loopback. Em uma rede na qual você não confia, adicione uma entrada personalizada com nome de usuário e senha para os outros dispositivos e feche as portas SOCKS e HTTP integradas, que não exigem senha, ou bloqueie-as no firewall.</p>
<h2 id="entradas-personalizadas">Entradas personalizadas</h2>
<p><strong>Configurações → Portas de entrada personalizadas</strong> adiciona entradas SOCKS ou HTTP com sua própria porta, nome de usuário e senha opcionais e seu próprio roteamento: um grupo de proxy fixo ou regras RoutingA escritas para aquela entrada, com o grupo escolhido como destino quando nenhuma regra corresponder (<code>default:</code> é ignorado ali). Assim, duas entradas personalizadas podem enviar tráfego para dois grupos diferentes, e uma entrada cujas regras terminam em <code>network(tcp, udp) -&gt; direct</code> não usa o proxy para nenhum aplicativo configurado para usá-la.</p>
<p>A tag é o nome da entrada na configuração do núcleo e nas condições <code>inboundTag(...)</code>.</p>
<h2 id="docker-e-mapeamento-de-portas">Docker e mapeamento de portas</h2>
<p>Em um contêiner iniciado com <code>--network=host</code>, as entradas e o proxy transparente atuam no host. Com a rede em modo bridge, publique a porta 2017 e as portas de entrada que você usa e ative Compartilhamento de portas para que escutem nas interfaces do contêiner; nesse caso, o proxy transparente vê apenas o contêiner. O v2rayA não consegue determinar se uma porta mapeada está livre no host.</p>
`;export{a as default};
