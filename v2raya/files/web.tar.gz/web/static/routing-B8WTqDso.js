const e=`<h1 id="routing-rules">Routing rules</h1>
<p>RoutingA is the rule language of v2rayA. <strong>Settings → RoutingA</strong> opens the editor; the rules apply to the rule port (<code>20172</code>) when its mode is RoutingA and to the transparent proxy when its policy is <em>Same as the rule port</em>. A custom inbound bound to RoutingA has its own rule text, see below.</p>
<h2 id="syntax">Syntax</h2>
<p>One rule per line: conditions, joined with <code>&amp;&amp;</code>, then <code>-&gt;</code> and an outbound. Rules match from top to bottom and the first match wins; <code>default:</code> names the outbound for everything unmatched. A line starting with <code>#</code> is a comment. v2rayA puts a few rules of its own in front: the proxy servers&#39; addresses and Apple&#39;s push service go direct, and an <code>inboundTag(...)</code> condition replaces the rule&#39;s usual inbound scope.</p>
<pre><code>default: proxy
domain(geosite:category-ads-all) -&gt; block
domain(geosite:cn) -&gt; direct
ip(geoip:private, geoip:cn) -&gt; direct
</code></pre>
<table>
<thead>
<tr>
<th>Condition</th>
<th>Matches</th>
</tr>
</thead>
<tbody><tr>
<td><code>domain(...)</code></td>
<td><code>domain:</code> the domain and its subdomains, <code>full:</code> exact, <code>regexp:</code>, <code>geosite:&lt;category&gt;</code>, <code>ext:&quot;file.dat:tag&quot;</code>; a bare value such as <code>example.com</code> matches as a substring</td>
</tr>
<tr>
<td><code>ip(...)</code></td>
<td>an address, a CIDR (quote IPv6: <code>ip(&quot;2001:db8::/32&quot;)</code>), <code>geoip:&lt;code&gt;</code>, <code>ext:&quot;file.dat:tag&quot;</code></td>
</tr>
<tr>
<td><code>port(...)</code></td>
<td>destination ports and ranges, <code>port(80, 443, 1000-2000)</code></td>
</tr>
<tr>
<td><code>sourcePort(...)</code></td>
<td>source ports</td>
</tr>
<tr>
<td><code>network(...)</code></td>
<td><code>tcp</code>, <code>udp</code></td>
</tr>
<tr>
<td><code>protocol(...)</code></td>
<td>sniffed protocol: <code>http</code>, <code>tls</code>, <code>quic</code>, <code>bittorrent</code> (needs <strong>Sniffing</strong> on)</td>
</tr>
<tr>
<td><code>source(...)</code></td>
<td>source addresses and CIDRs</td>
</tr>
<tr>
<td><code>inboundTag(...)</code></td>
<td>the inbound the connection arrived on</td>
</tr>
</tbody></table>
<h2 id="outbounds">Outbounds</h2>
<p><code>proxy</code>, <code>direct</code> and <code>block</code> are built in. Every other proxy group is an outbound under its own name once it has a connected member; the rules fail to apply otherwise. A SOCKS or HTTP server outside v2rayA is declared once and used like a group (an <code>ext:</code> file goes into the rule-data directory):</p>
<pre><code>outbound: office = socks(address: 192.168.1.10, port: 1080)
outbound: gateway = http(address: 10.0.0.1, port: 8080, user: &#39;name&#39;, pass: &#39;secret&#39;)
domain(domain: corp.example) -&gt; office
</code></pre>
<h2 id="categories">Categories</h2>
<p><code>geosite:</code> categories come from the v2fly <a href="https://github.com/v2fly/domain-list-community">domain-list-community</a> and <code>geoip:</code> codes from <a href="https://github.com/v2fly/geoip">v2fly/geoip</a>; v2rayA downloads whichever file is missing on first start, a package may ship its own build. Frequently used: <code>geosite:cn</code>, <code>geosite:geolocation-!cn</code>, <code>geosite:private</code>, <code>geosite:category-ads-all</code>, <code>geosite:greatfire</code>, <code>geosite:netflix</code>, <code>geosite:youtube</code>, <code>geosite:telegram</code>, <code>geosite:openai</code>; <code>geoip:cn</code>, <code>geoip:private</code> and the country codes. An attribute narrows a category: <code>geosite:apple@cn</code>, <code>geosite:category-games@cn</code>.</p>
<p>Names that exist only in Loyalsoldier&#39;s builds (<code>gfw</code>, <code>apple-cn</code>, <code>google-cn</code>, <code>geoip:telegram</code>) are not in these files; the core refuses them with <code>illegal domain rule</code> or <code>illegal ip rule</code>. <strong>Update GFWList</strong> downloads that build (from <code>v2rayA/dist-v2ray-rules-dat</code>) as <code>LoyalsoldierSite.dat</code>, and rules can then use it as <code>domain(ext:&quot;LoyalsoldierSite.dat:gfw&quot;)</code>.</p>
<h2 id="the-editor">The editor</h2>
<p>The list mode edits each rule with a form; the text mode shows line numbers, colouring and a check per line. The reference beside the editor inserts examples at the cursor, and its <strong>Templates</strong> section holds complete rule sets for the common policies: insert one above your own rules, or replace the whole rule set with it. Rules are imported and exported as a text file.</p>
<p>The Russia template sends <code>geosite:category-ru</code> directly, except for its listed proxy-first domains; everything else uses the proxy. It is a bundled snapshot of <a href="https://github.com/wywywywycloud/routinga-russia">routinga-russia</a>, not a live-updating list, and requires a <code>geosite.dat</code> containing <code>category-ru</code>.</p>
<p>Russian IP addresses (<code>geoip:ru</code>) and private hostnames and IP addresses (<code>geosite:private</code>, <code>geoip:private</code>) also go directly; the proxy exceptions take precedence.</p>
<p>Saving reloads a running core with the new rules; when the core rejects them, v2rayA puts the previous rules back and shows the core&#39;s error, which names the offending text. A stopped core takes the rules on its next start.</p>
<h2 id="custom-inbounds">Custom inbounds</h2>
<p>A custom inbound bound to RoutingA has its own rule text that applies to that inbound only. It takes rules, not definitions: <code>default:</code> and <code>outbound:</code> lines are ignored, and traffic no rule matches goes to the group chosen in the form. End the text with a catch-all such as <code>network(tcp, udp) -&gt; direct</code> to route everything else yourself.</p>
`;export{e as default};
