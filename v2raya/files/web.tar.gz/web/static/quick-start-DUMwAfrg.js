const o=`<h1 id="빠른-시작">빠른 시작</h1>
<p>브라우저의 이 페이지에서 v2rayA를 설정하고 상태를 확인합니다. 서비스는 root 권한으로 실행되며(Windows에서는 관리자 권한, <code>--lite</code> 사용 시에는 일반 사용자 권한) <code>v2raya_core</code>를 직접 시작합니다.</p>
<h2 id="로그인">로그인</h2>
<p>처음 등록한 계정이 관리자이며, 다른 계정은 없습니다. 등록할 때는 사용자 이름과 6~32자의 비밀번호를 입력하며 기존 인증 정보는 필요하지 않습니다. 따라서 공유 네트워크에서는 등록 전에 포트 2017에 접근할 수 있는 사용자를 제한하거나, <code>--address 127.0.0.1:2017</code>로 서비스를 실행해 로컬에서만 사용하세요.</p>
<p>비밀번호를 잊었다면 서비스를 중지한 상태에서 명령줄로 재설정합니다.</p>
<pre><code class="language-sh">v2raya --reset-password
</code></pre>
<p>서비스가 사용하는 계정과 <code>--config</code> 디렉터리로 실행하세요(lite 모드에서는 <code>--lite</code>도 사용). Windows에서는 서비스가 SYSTEM 계정으로 실행되며, 관리자 권한으로 실행한 사용자의 디렉터리와 서비스의 디렉터리가 다릅니다. 서비스를 다시 시작하고 새 계정을 등록하세요.</p>
<h2 id="노드-가져오기">노드 가져오기</h2>
<p><strong>프록시</strong> 페이지의 <strong>가져오기</strong>에서 공유 링크나 구독을 가져옵니다. <strong>서버 링크</strong>를 선택하면 <code>vmess://</code>, <code>vless://</code>, <code>ss://</code>, <code>trojan://</code>, <code>hysteria2://</code>, <code>tuic://</code>, <code>juicity://</code>, <code>anytls://</code>, <code>wireguard://</code>, <code>socks5://</code>, <code>http://</code>, <code>https://</code> 링크를 한 줄에 하나씩 입력하거나 QR 코드 이미지를 사용할 수 있습니다. 구독을 가져오려면 <strong>구독 주소</strong>를 선택하세요. ShadowsocksR 링크는 거부되며, 스트림 암호(<code>rc4-md5</code>, <code>aes-*-cfb</code>, <code>chacha20-ietf</code>)나 <code>none</code>을 쓰는 Shadowsocks 링크도 거부됩니다. 코어는 AEAD 암호와 2022-blake3 방식만 받습니다. 링크의 <code>allow_insecure</code>는 무시됩니다. v2rayA는 인증서 검증을 건너뛰지 않으므로, 자체 서명 서버는 노드 양식에 인증서 SHA-256을 고정하세요.</p>
<p>구독은 <strong>구독</strong> 페이지에 따로 있습니다(휴대폰에서는 자리를 내기 위해 문서 항목이 상단 바 메뉴로 옮겨집니다). 구독에 속한 노드는 함께 관리되며, 수동으로 또는 예약에 따라 업데이트할 수 있습니다(<strong>설정 → 구독 자동 업데이트</strong>). 옆의 모드 설정은 업데이트할 때 프록시를 사용할지 결정합니다.</p>
<h2 id="그룹">그룹</h2>
<p>노드는 프록시 그룹을 통해 사용합니다. <code>proxy</code> 그룹은 항상 존재하며, 다른 그룹은 상단 바의 그룹 버튼에서 만들고 설정하고 삭제하며, 그룹 관리는 그곳에서만 합니다. 노드는 노드 메뉴에서 그룹에 넣거나, 프록시 페이지에서 여러 개를 선택한 뒤 <strong>프록시 그룹에 추가</strong>에서 그룹을 고릅니다. 연결된 구성원이 여러 개인 그룹은 측정된 지연 시간이 가장 짧은 노드를 사용합니다(<strong>자동 (최저 지연 시간)</strong>). 대시보드의 노드 메뉴에서 구성원 하나를 고정하면 그룹은 해당 노드만 사용합니다. <strong>노드 추가/삭제</strong>에서 구성원을 변경하고, 그룹 설정에서 지연 시간 측정에 사용할 주소와 측정 간격을 설정합니다.</p>
<p>라우팅 규칙에서는 그룹 이름으로 아웃바운드를 지정합니다. 기본값은 <code>proxy</code>이며, 다른 그룹도 연결된 구성원이 있으면 그룹 이름으로 지정할 수 있습니다.</p>
<h2 id="코어-시작">코어 시작</h2>
<p>대시보드의 <strong>시작</strong> 또는 페이지 상단의 상태 버튼을 누르면 현재 설정으로 <code>v2raya_core</code>를 시작합니다. 설정 페이지의 변경 사항은 <strong>저장 및 적용</strong>을 눌러 적용합니다. 실행 중인 코어는 변경된 설정으로 다시 시작하며, 중지된 코어는 다음 시작 시 적용합니다.</p>
<p>코어가 실행되면 애플리케이션은 로컬 인바운드를 통해 코어에 연결합니다.</p>
<table>
<thead>
<tr>
<th>인바운드</th>
<th>주소</th>
<th>라우팅</th>
</tr>
</thead>
<tbody><tr>
<td>SOCKS5</td>
<td><code>127.0.0.1:20170</code></td>
<td>모든 트래픽을 <code>proxy</code>로 전달</td>
</tr>
<tr>
<td>HTTP</td>
<td><code>127.0.0.1:20171</code></td>
<td>모든 트래픽을 <code>proxy</code>로 전달</td>
</tr>
<tr>
<td>규칙 적용 HTTP</td>
<td><code>127.0.0.1:20172</code></td>
<td><strong>규칙 포트의 트래픽 분할 모드</strong> 설정</td>
</tr>
</tbody></table>
<p>포트는 <strong>설정 → 주소 및 포트</strong>에서 변경합니다. 0으로 설정하면 인바운드가 닫힙니다. 애플리케이션을 각각 설정하지 않고 프록시를 적용하려면 투명 프록시를 켜세요.</p>
<h2 id="라우팅">라우팅</h2>
<p><strong>설정 → 트래픽 분할</strong>에서 규칙 포트와 투명 프록시의 트래픽 분할 방식을 선택합니다. 중국 사이트를 제외한 모든 트래픽에 프록시를 적용하거나, GFWList에만 적용하거나, 직접 작성한 RoutingA 규칙을 사용할 수 있습니다. RoutingA는 별도 섹션에서 설명합니다.</p>
<h2 id="키보드">키보드</h2>
<ul>
<li>프록시 페이지 목록 보기: <code>Ctrl</code>+<code>A</code>는 표시된 모든 노드를 선택하고 <code>Esc</code>는 선택을 해제합니다. 프록시와 로그 페이지에서 <code>/</code>는 검색창으로 이동합니다.</li>
<li>설정: <code>Ctrl</code>+<code>S</code>로 저장합니다. RoutingA 편집기: <code>Ctrl</code>+<code>S</code> 저장, <code>Tab</code> 들여쓰기.</li>
<li>여러 줄 입력이 있는 대화 상자(가져오기, 구독, 라우팅 스크립트, 목록): <code>Ctrl</code>+<code>Enter</code>로 제출하고 <code>Esc</code>로 어떤 대화 상자든 닫습니다.</li>
<li>로그: 포커스가 있으면 <code>Home</code>, <code>End</code>, <code>PgUp</code>, <code>PgDn</code>으로 이동합니다.</li>
</ul>
<p>macOS에서는 <code>Cmd</code>가 <code>Ctrl</code>을 대신합니다.</p>
`;export{o as default};
