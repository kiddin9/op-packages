const o=`<h1 id="opções-e-variáveis-de-ambiente">Opções e variáveis de ambiente</h1>
<p>Cada opção tem uma variável de ambiente de mesmo nome: <code>--log-level</code> é <code>V2RAYA_LOG_LEVEL</code>. A unidade de serviço do Linux define <code>V2RAYA_LOG_FILE</code> e lê <code>/etc/default/v2raya</code>; as demais mantêm seus padrões. A tabela abaixo é lida do serviço em execução e mostra os valores padrão declarados, não os valores em uso; quando o valor padrão está vazio, ele é calculado na inicialização.</p>
<h2 id="hooks">Hooks</h2>
<p><code>--transparent-hook</code> indica um executável que é executado antes e depois da configuração e da remoção do proxy transparente, com <code>--transparent-type=&lt;redirect|tproxy|tun|system_proxy&gt;</code>, <code>--stage=&lt;pre-start|post-start|pre-stop|post-stop&gt;</code> e <code>--v2raya-confdir=&lt;directory&gt;</code> como argumentos. <code>--core-hook</code> é executado antes e depois de o núcleo iniciar e parar, com <code>--stage</code> e <code>--v2raya-confdir</code>. Os scripts de rota para <code>tun</code> com <strong>Rota automática</strong> desativada ficam em uma configuração separada, <strong>Configurar script de rota</strong>.</p>
<h2 id="diretórios">Diretórios</h2>
<table>
<thead>
<tr>
<th>Conteúdo</th>
<th>Local</th>
</tr>
</thead>
<tbody><tr>
<td>configuração e <code>v2raya.db</code></td>
<td><code>--config</code>; padrão <code>/etc/v2raya</code> no Linux e no macOS, <code>%ProgramData%\\SYSTEM\\v2rayA</code> para o serviço do Windows, <code>~/.config/v2raya</code> (ou <code>%AppData%\\v2rayA</code>) no modo lite</td>
</tr>
<tr>
<td>configuração gerada do núcleo</td>
<td><code>config.json</code> no diretório de configuração</td>
</tr>
<tr>
<td>dados de regras (<code>geoip.dat</code>, <code>geosite.dat</code>)</td>
<td><code>--v2ray-assetsdir</code>; caso contrário, a busca usa os diretórios de dados XDG (<code>/usr/share/v2raya</code>, <code>/usr/local/share/v2raya</code>, <code>~/.local/share/v2raya</code>) e os arquivos baixados ficam no diretório de dados XDG do usuário; no Windows, o diretório <code>data</code> do instalador ou o diretório de configuração</td>
</tr>
<tr>
<td>o núcleo</td>
<td><code>--v2ray-bin</code>; padrão <code>v2raya_core</code> ao lado de <code>v2raya</code> ou em <code>PATH</code></td>
</tr>
<tr>
<td>registros</td>
<td><code>--log-file</code> ou <code>V2RAYA_LOG_FILE</code>, caso contrário, o console; a unidade de sistema do Linux usa <code>/var/log/v2raya/v2raya.log</code>, a unidade de usuário usa <code>~/.local/state/v2raya/v2raya.log</code>, e o instalador do Windows usa <code>%TEMP%\\v2raya.log</code></td>
</tr>
</tbody></table>
`;export{o as default};
