const e=`<h1 id="quick-start">Quick start</h1>
<p>This page in the browser configures v2rayA and shows its state; the service runs as root (as an administrator on Windows; unprivileged with <code>--lite</code>) and starts <code>v2raya_core</code> itself.</p>
<h2 id="sign-in">Sign in</h2>
<p>The first account registered is the administrator; there is no other account. Registration asks for a username and a password of 6 to 32 characters and needs no existing credentials, so on a shared network restrict who can reach port 2017 before you register, or run the service with <code>--address 127.0.0.1:2017</code> for local use only.</p>
<p>A forgotten password is reset from the command line, with the service stopped:</p>
<pre><code class="language-sh">v2raya --reset-password
</code></pre>
<p>Run it with the account and the <code>--config</code> directory the service uses (<code>--lite</code> too in lite mode); on Windows the service runs as SYSTEM and its directory differs from an elevated user&#39;s. Start the service again and register a new account.</p>
<h2 id="import-nodes">Import nodes</h2>
<p>On the <strong>Proxies</strong> page, <strong>Import</strong> takes share links or a subscription: choose <strong>Server link</strong> for <code>vmess://</code>, <code>vless://</code>, <code>ss://</code>, <code>trojan://</code>, <code>hysteria2://</code>, <code>tuic://</code>, <code>juicity://</code>, <code>anytls://</code>, <code>wireguard://</code>, <code>socks5://</code>, <code>http://</code> and <code>https://</code> links, one per line, or a QR code image; choose <strong>Subscription address</strong> for a subscription. ShadowsocksR links are refused, and so are Shadowsocks links with a stream cipher (<code>rc4-md5</code>, <code>aes-*-cfb</code>, <code>chacha20-ietf</code>) or <code>none</code>: the core accepts the AEAD ciphers and the 2022-blake3 methods only. <code>allow_insecure</code> in a link is ignored: v2rayA never skips certificate verification; for a self-signed server, pin its certificate SHA-256 in the node&#39;s form.</p>
<p>Subscriptions have their own page, <strong>Subscriptions</strong> (on a phone the docs move to the app bar&#39;s menu to make room for it). They keep their nodes together and can be updated by hand or on a schedule (<strong>Settings → Automatically Update Subscriptions</strong>). The mode setting next to it decides whether the update goes through the proxy.</p>
<h2 id="groups">Groups</h2>
<p>Nodes are used through proxy groups. The group <code>proxy</code> always exists; more are created, renamed, configured and deleted from the group button in the app bar, the only place for that. A node joins a group from its menu, or select several on the Proxies page and pick the group under <strong>Add to proxy group</strong>. A group with several connected members uses the one with the lowest measured latency (<strong>Auto (lowest latency)</strong>); the node menu on the dashboard pins one member so the group uses it alone, <strong>Add or remove nodes</strong> changes the members, and the group settings set the probe address and interval.</p>
<p>The routing rules name groups as outbounds: <code>proxy</code> by default, and any other group by its name once it has a connected member.</p>
<h2 id="start-the-core">Start the core</h2>
<p><strong>Start</strong> on the dashboard, or the status button at the top of the page, starts <code>v2raya_core</code> with the current configuration. Changes on the Settings page take effect with <strong>Save and Apply</strong>: a running core is restarted with them, a stopped core picks them up on the next start.</p>
<p>Once the core runs, applications reach it through the local inbounds:</p>
<table>
<thead>
<tr>
<th>Inbound</th>
<th>Address</th>
<th>Routing</th>
</tr>
</thead>
<tbody><tr>
<td>SOCKS5</td>
<td><code>127.0.0.1:20170</code></td>
<td>everything through <code>proxy</code></td>
</tr>
<tr>
<td>HTTP</td>
<td><code>127.0.0.1:20171</code></td>
<td>everything through <code>proxy</code></td>
</tr>
<tr>
<td>HTTP with rules</td>
<td><code>127.0.0.1:20172</code></td>
<td>the <strong>Traffic Splitting Mode of Rule Port</strong> setting</td>
</tr>
</tbody></table>
<p>The ports are changed under <strong>Settings → Address and Ports</strong>; 0 closes an inbound. To cover applications without configuring each, turn on the transparent proxy.</p>
<h2 id="routing">Routing</h2>
<p><strong>Settings → Traffic splitting</strong> picks how the rule port and the transparent proxy split traffic: proxy everything except Chinese sites, proxy only the GFWList, or your own RoutingA rules. RoutingA is described in its own section.</p>
<h2 id="keyboard">Keyboard</h2>
<ul>
<li>Proxies, list view: <code>Ctrl</code>+<code>A</code> selects every listed node, <code>Esc</code> clears the selection; <code>/</code> goes to the search on the Proxies and Logs pages.</li>
<li>Settings: <code>Ctrl</code>+<code>S</code> saves. RoutingA editor: <code>Ctrl</code>+<code>S</code> saves, <code>Tab</code> indents.</li>
<li>Dialogs with a text area (import, subscription, route scripts, lists): <code>Ctrl</code>+<code>Enter</code> submits; <code>Esc</code> closes any dialog.</li>
<li>Logs: <code>Home</code>, <code>End</code>, <code>PgUp</code>, <code>PgDn</code> move through the log once it has focus.</li>
</ul>
<p>On macOS <code>Cmd</code> stands for <code>Ctrl</code>.</p>
`;export{e as default};
