const o=`<h1 id="proxy-transparente">Proxy transparente</h1>
<p>Com o proxy transparente ativado, o tráfego chega ao núcleo sem nenhuma configuração nos aplicativos; o tráfego abrangido depende da implementação. <strong>Configurações → Proxy transparente/Proxy do sistema</strong> ativa o recurso e seleciona a política de divisão; a configuração abaixo seleciona a implementação.</p>
<h2 id="políticas">Políticas</h2>
<table>
<thead>
<tr>
<th>Política</th>
<th>Tráfego pelo proxy</th>
</tr>
</thead>
<tbody><tr>
<td>Não dividir</td>
<td>tudo</td>
</tr>
<tr>
<td>Proxy exceto sites da China</td>
<td>tudo, exceto domínios e endereços chineses (<code>geosite:cn</code>, <code>geoip:cn</code>) e endereços privados; sites fora da China, Google e endereços de Hong Kong e Macau passam pelo proxy mesmo quando uma regra chinesa corresponde</td>
</tr>
<tr>
<td>Proxy apenas para GFWList</td>
<td>os domínios da GFWList (<code>gfw</code> e <code>greatfire</code> do arquivo de Loyalsoldier) e as faixas de endereços do Telegram; execute <strong>Atualizar GFWList</strong> primeiro, pois o modo é recusado sem o arquivo</td>
</tr>
<tr>
<td>Igual ao da porta de regras</td>
<td>o modo da porta de regras, incluindo RoutingA</td>
</tr>
</tbody></table>
<h2 id="implementações">Implementações</h2>
<table>
<thead>
<tr>
<th>Implementação</th>
<th>Plataformas</th>
<th>Observações</th>
</tr>
</thead>
<tbody><tr>
<td><code>redirect</code></td>
<td>Linux</td>
<td><code>REDIRECT</code> do iptables/nftables; apenas TCP, além de DNS na porta 53 redirecionado ao módulo DNS do núcleo (porta 52353) no modo <em>serviço e interceptação</em></td>
</tr>
<tr>
<td><code>tproxy</code></td>
<td>Linux</td>
<td><code>TPROXY</code> do iptables/nftables; TCP e UDP</td>
</tr>
<tr>
<td><code>tun</code></td>
<td>Linux, Windows, macOS</td>
<td>o núcleo abre um dispositivo TUN; TCP e UDP; exclui o v2rayA e o próprio núcleo automaticamente</td>
</tr>
<tr>
<td>Proxy do sistema</td>
<td>Windows; Linux e macOS quando não é executado como root (<code>--lite</code>)</td>
<td>configura o proxy do ambiente gráfico (GNOME e KDE no Linux); abrange apenas os aplicativos que as respeitam</td>
</tr>
</tbody></table>
<p><code>redirect</code> e <code>tproxy</code> exigem root e <code>iptables</code> ou <code>nftables</code>; <code>tun</code> exige <code>/dev/net/tun</code> e <code>ip</code> no Linux e privilégios de administrador no Windows e no macOS.</p>
<p><strong>Prefixos de interfaces excluídos</strong> mantém o tráfego que chega pelas interfaces indicadas (bridges do Docker, túneis VPN; <code>docker*</code>, <code>veth*</code>, <code>wg*</code>, <code>ppp*</code> por padrão) fora de <code>redirect</code> e <code>tproxy</code>; o DNS dessas interfaces só é interceptado no modo <em>serviço e interceptação</em>.</p>
<p><code>--redirect-respect-bound-device</code> (Linux) deixa as conexões TCP vinculadas a uma interface com <code>SO_BINDTODEVICE</code> fora do <code>redirect</code>: as verificações de conectividade do NetworkManager são conexões desse tipo e, redirecionadas, informam uma conexão limitada e mantêm os aplicativos offline. Desligado por padrão. Quando ligado, o serviço marca esses sockets com <code>0x80</code> por cgroup BPF; isso requer kernel 5.14 ou mais recente e cgroup v2, e sem eles o <code>redirect</code> não inicia.</p>
<h2 id="tun">TUN</h2>
<p>O núcleo cria o dispositivo TUN e atribui seu endereço. Com <strong>Rota automática</strong> ativada, o v2rayA instala as rotas e, no modo <em>serviço e interceptação</em>, direciona o resolvedor do sistema para o núcleo; com ela desativada, os scripts de configuração e remoção em <strong>Configurar script de rota</strong> fazem isso.</p>
<p>Nunca entram no TUN: as conexões do próprio núcleo, a saída <code>direct</code> e as consultas do módulo DNS aos servidores upstream (por marca de socket no Linux, por vinculação à interface física no Windows e no macOS). O v2rayA e o núcleo são sempre excluídos; <strong>Processos excluídos do TUN</strong> exclui outros pelo nome do executável, um por linha, para conexões cujo processo responsável pode ser identificado; no modo <em>serviço e interceptação</em>, o DNS desses processos ainda vai para o módulo DNS do núcleo. Rotas mais específicas que a padrão (redes conectadas, rotas estáticas) também não passam pelo TUN.</p>
<p>No modo <em>serviço e interceptação</em>, o DNS sem criptografia na porta 53 que chega ao TUN é respondido pelo módulo DNS do núcleo de acordo com as regras de DNS; o DNS criptografado não é interceptado. Nesse caso, no Windows, o resolvedor do sistema é direcionado para o gateway do TUN; no macOS, para o serviço do núcleo que escuta em <code>127.0.0.1</code>, que precisa da porta 53 livre.</p>
<p>Nos outros dois modos o TUN não monta esse relay e o resolvedor do sistema não é alterado em nenhuma das duas plataformas; uma consulta que ainda chegar sai direto do dispositivo. O mesmo vale com a <strong>Rota automática</strong> desligada e o script de rota no comando da rede: o v2rayA não muda a configuração do resolvedor, então o DNS também cabe ao script.</p>
<p>Limitação conhecida: no Windows e no macOS, um aplicativo que consulta diretamente um resolvedor da rede local ainda não passa pelo TUN.</p>
<h2 id="dns">DNS</h2>
<p><strong>Configurações → Configurações de DNS</strong> contém o modo do DNS e as regras que o módulo DNS do núcleo segue.</p>
<table>
<thead>
<tr>
<th>Modo</th>
<th>Módulo DNS</th>
<th>Consultas do sistema</th>
</tr>
</thead>
<tbody><tr>
<td>Desligado</td>
<td>não roda</td>
<td>não são alteradas</td>
</tr>
<tr>
<td>Somente serviço</td>
<td>roda</td>
<td>não são alteradas: o resolvedor, as regras de DNS do firewall e o relay da TUN ficam como estão</td>
</tr>
<tr>
<td>Serviço e interceptação</td>
<td>roda</td>
<td>são direcionadas a ele: o resolvedor é reapontado e a porta 53 é desviada</td>
</tr>
</tbody></table>
<p>O modo responde a duas perguntas que antes se confundiam: se o módulo roda e se as consultas do sistema vão para ele — e o modo <em>somente serviço</em> responde de forma diferente às duas. <em>Desligado</em> e <em>somente serviço</em> deixam o TCP/UDP simples na porta 53 passar em <code>redirect</code>, <code>tproxy</code> e no proxy do sistema, e o <code>tun</code> o envia direto para fora; o DNS criptografado nunca vai para o módulo, então não há motivo para abdicar da interceptação por causa dele. Escolha <em>somente serviço</em> quando outro programa já aponta o DNS para o v2rayA, e <em>desligado</em> quando nada deve responder DNS por você.</p>
<p>As regras dizem qual servidor upstream responde por quais domínios e se a consulta sai diretamente. Os padrões enviam nomes privados para <code>127.0.0.1:53</code> (<code>localhost</code>, que precisa de um resolvedor escutando ali), <code>geosite:cn</code> diretamente para <code>223.5.5.5</code> e todo o resto para <code>1.0.0.1</code> pelo proxy. Uma saída <code>direct</code> consulta diretamente; qualquer outro valor envia a consulta pela entrada SOCKS local, de modo que ela é roteada como tráfego SOCKS. A regra com uma lista de domínios vazia responde por todos os domínios que nenhuma outra regra indica. Um servidor upstream é um endereço (<code>8.8.8.8</code>, <code>dns.google</code>), <code>tcp://host</code>, <code>tls://host</code> para DNS sobre TLS ou <code>https://host/dns-query</code> para DNS sobre HTTPS; DNS sobre QUIC não é suportado e é recusado ao salvar.</p>
<p><em>Desligado</em> esconde as regras e as mantém: nada as leria de qualquer forma, e apagá-las faria com que religar o modousse uma configuração diferente.</p>
<p>Salvar grava as regras e o modo em duas requisições, e a caixa de diálogo informa qual delas o serviço aceitou. Uma recusa depois de as regras terem sido gravadas é dita como tal, para que a nova tentativa envie apenas o que falta.</p>
<h2 id="compartilhamento-com-a-rede-local">Compartilhamento com a rede local</h2>
<p><strong>Compartilhamento de portas</strong> faz as entradas SOCKS, HTTP e personalizadas escutarem em todas as interfaces em vez de <code>127.0.0.1</code>, para que outros dispositivos possam usar esta máquina como proxy; a porta da API permanece no loopback. Para rotear o tráfego desses dispositivos também pelo proxy transparente, use <code>redirect</code>, <code>tproxy</code> ou <code>tun</code>, ative <strong>Encaminhamento de IP</strong>, mantenha a interface pela qual o tráfego chega fora dos prefixos excluídos e direcione o gateway padrão dos dispositivos para esta máquina; os modos de proxy do sistema não podem fazer isso.</p>
`;export{o as default};
